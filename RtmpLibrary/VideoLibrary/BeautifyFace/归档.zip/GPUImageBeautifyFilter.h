 

#import "GPUImage/GPUImage.h"

#import "BeautifyFace.h"
 @class GPUImageCombinationFilter;
@class BeautifyFace;
@interface GPUImageBeautifyFilter : GPUImageFilterGroup{
    GPUImageBilateralFilter *bilateralFilter;
    GPUImageSobelEdgeDetectionFilter  *cannyEdgeFilter;
    GPUImageCombinationFilter *combinationFilter;
    GPUImageHSBFilter *hsbFilter;

    bool isOnece;
}

 @property (assign,nonatomic)BeautifyFace* pBeautifyFace;


- (void)openBeautify;
- (void)closeBeautify;
@end
